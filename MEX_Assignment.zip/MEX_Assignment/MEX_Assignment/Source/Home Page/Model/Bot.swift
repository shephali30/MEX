//
//  Bot.swift
//  MEX_Assignment
//
//  Created by Shephali Srivas on 29/05/22.
//

import Foundation

struct Bot: Codable {
    var name: String?
    var date: Double = 0
}
