//
//  HomeTableViewCell.swift
//  MEX_Assignment
//
//  Created by Shephali Srivas on 29/05/22.
//

import UIKit

class HomeTableViewCell: UITableViewCell {
    @IBOutlet weak var botName: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
}
