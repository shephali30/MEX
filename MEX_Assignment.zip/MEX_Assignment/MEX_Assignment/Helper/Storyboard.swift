//
//  Storyboard.swift
//  MEX_Assignment
//
//  Created by Shephali Srivas on 29/05/22.
//

import UIKit

class Storyboard {
    static func HomeStoryBoard() -> UIStoryboard {
        return UIStoryboard(name: "Home", bundle: nil)
    }
}
